from pathlib import Path
import os
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from decimal import Decimal, InvalidOperation

def database(path):
    db = sqlite3.connect(path)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS product(id INTEGER PRIMARY KEY, name TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>=0), qty INTEGER NOT NULL CHECK(qty>=0));
    CREATE TABLE IF NOT EXISTS sale(id INTEGER PRIMARY KEY, created TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS line(sale_id INTEGER REFERENCES sale, product_id INTEGER REFERENCES product, name TEXT NOT NULL, price INTEGER NOT NULL, qty INTEGER NOT NULL CHECK(qty>0), PRIMARY KEY(sale_id,product_id));
    """)
    return db

def sell(db, cart):
    if not cart:
        raise ValueError("Panier vide.")
    with db:
        sale_id = db.execute("INSERT INTO sale DEFAULT VALUES").lastrowid
        for pid, qty in cart.items():
            if qty <= 0 or not isinstance(qty, int):
                raise ValueError("Quantité invalide.")
            changed = db.execute("UPDATE product SET qty=qty-? WHERE id=? AND qty>=?", (qty,pid,qty))
            if not changed.rowcount:
                raise ValueError("Stock insuffisant.")
            db.execute("INSERT INTO line SELECT ?,id,name,price,? FROM product WHERE id=?", (sale_id,qty,pid))
    return sale_id

def money(cents):
    return f"{cents // 100},{cents % 100:02d}"

def main():
    folder = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "StockRebuild"
    folder.mkdir(exist_ok=True)
    db = database(folder / "stock.sqlite")
    root = tk.Tk()
    root.title("Stock • Gestion commerciale")
    root.geometry("900x560")
    tabs = ttk.Notebook(root)
    tabs.pack(fill="both", expand=True)
    cart = {}
    def panel(title, headers):
        page = ttk.Frame(tabs, padding=12)
        tabs.add(page, text=title)
        bar = ttk.Frame(page)
        bar.pack(fill="x")
        tree = ttk.Treeview(page, columns=headers, show="headings",selectmode="browse")
        for col in headers:
            tree.heading(col, text=col)
            tree.column(col, width=120)
        tree.pack(fill="both",expand=True,pady=8)
        return bar, tree
    pb, products = panel("Articles et stock",("Réf.","Désignation","Prix","Stock"))
    cb, basket = panel("Vente",("Réf.","Désignation","Quantité","Montant"))
    hb, history = panel("Historique des ventes",("N°","Date locale","Total"))
    def refresh():
        for tree in (products,basket,history):
            tree.delete(*tree.get_children())
        for pid,name,price,qty in db.execute("SELECT * FROM product ORDER BY name"):
            products.insert("", "end",iid=str(pid),values=(pid,name,money(price),qty))
            if pid in cart:
                basket.insert("", "end",iid=str(pid),values=(pid,name,cart[pid],money(price*cart[pid])))
        for sid,date,total in db.execute("SELECT s.id,datetime(created,'localtime'),sum(l.price*l.qty) FROM sale s JOIN line l ON l.sale_id=s.id GROUP BY s.id ORDER BY s.id DESC"):
            history.insert("","end",values=(sid,date,money(total)))
    def add():
        name = simpledialog.askstring("Article","Désignation",parent=root)
        if not name or not name.strip(): return
        raw = simpledialog.askstring("Article","Prix unitaire",parent=root)
        if raw is None: return
        try:
            cents = Decimal(raw.replace(",", "."))*100
            if not cents.is_finite() or not 0<=cents<=999999999 or cents != int(cents):
                raise ValueError()
        except (InvalidOperation,ValueError):
            messagebox.showerror("Prix","Saisissez un prix positif ou nul avec deux décimales maximum.")
            return
        qty = simpledialog.askinteger("Article","Quantité initiale",minvalue=0,maxvalue=999999,parent=root)
        if qty is None: return
        with db:
            db.execute("INSERT INTO product(name,price,qty) VALUES(?,?,?)",(name.strip(),int(cents),qty))
        refresh()
    def choose():
        if not products.selection(): return
        pid = int(products.selection()[0])
        remaining = db.execute("SELECT qty FROM product WHERE id=?",(pid,)).fetchone()[0]-cart.get(pid,0)
        if remaining<=0:
            messagebox.showinfo("Stock","Quantité disponible épuisée.")
            return
        qty = simpledialog.askinteger("Panier","Quantité",minvalue=1,maxvalue=remaining,parent=root)
        if qty:
            cart[pid]=cart.get(pid,0)+qty
            refresh()
    def remove():
        if basket.selection():
            del cart[int(basket.selection()[0])]
            refresh()
    def confirm():
        try:
            sid=sell(db,cart)
        except (ValueError, sqlite3.Error) as err:
            messagebox.showerror("Vente",str(err))
            return
        cart.clear()
        refresh()
        messagebox.showinfo("Vente", f"Vente n° {sid} enregistrée.")
    for bar,label,cmd in [(pb,"Nouvel article",add),(pb,"Ajouter à la vente",choose),(cb,"Retirer la ligne",remove),(cb,"Valider la vente",confirm)]:
        ttk.Button(bar,text=label,command=cmd).pack(side="left",padx=4)
    refresh()
    root.mainloop()
    db.close()

if __name__ == "__main__":
    main()
